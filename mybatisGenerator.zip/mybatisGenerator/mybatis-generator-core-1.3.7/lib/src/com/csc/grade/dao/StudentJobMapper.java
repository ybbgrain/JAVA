package com.csc.grade.dao;

import com.csc.grade.entity.StudentJob;

public interface StudentJobMapper {
    int deleteByPrimaryKey(String id);

    int insert(StudentJob record);

    int insertSelective(StudentJob record);

    StudentJob selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(StudentJob record);

    int updateByPrimaryKey(StudentJob record);
}