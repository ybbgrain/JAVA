package com.csc.grade.dao;

import com.csc.grade.entity.CourseJob;

public interface CourseJobMapper {
    int deleteByPrimaryKey(String id);

    int insert(CourseJob record);

    int insertSelective(CourseJob record);

    CourseJob selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(CourseJob record);

    int updateByPrimaryKey(CourseJob record);
}