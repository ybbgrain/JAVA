package com.cqut.singularity.entity;

public class CompetitionCondition {
    private Integer competitionId;

    private String competitionContent;

    public Integer getCompetitionId() {
        return competitionId;
    }

    public void setCompetitionId(Integer competitionId) {
        this.competitionId = competitionId;
    }

    public String getCompetitionContent() {
        return competitionContent;
    }

    public void setCompetitionContent(String competitionContent) {
        this.competitionContent = competitionContent == null ? null : competitionContent.trim();
    }
}