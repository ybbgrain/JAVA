package com.cqut.singularity.dao;

import com.cqut.singularity.entity.CompetitionCondition;

public interface CompetitionConditionMapper {
    int deleteByPrimaryKey(Integer competitionId);

    int insert(CompetitionCondition record);

    int insertSelective(CompetitionCondition record);

    CompetitionCondition selectByPrimaryKey(Integer competitionId);

    int updateByPrimaryKeySelective(CompetitionCondition record);

    int updateByPrimaryKey(CompetitionCondition record);
}