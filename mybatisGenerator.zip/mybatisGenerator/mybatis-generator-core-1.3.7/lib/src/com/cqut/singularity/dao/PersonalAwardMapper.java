package com.cqut.singularity.dao;

import com.cqut.singularity.entity.PersonalAward;

public interface PersonalAwardMapper {
    int deleteByPrimaryKey(String awardNum);

    int insert(PersonalAward record);

    int insertSelective(PersonalAward record);

    PersonalAward selectByPrimaryKey(String awardNum);

    int updateByPrimaryKeySelective(PersonalAward record);

    int updateByPrimaryKey(PersonalAward record);
}