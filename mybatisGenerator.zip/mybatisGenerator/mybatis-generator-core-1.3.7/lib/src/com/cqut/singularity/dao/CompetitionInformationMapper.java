package com.cqut.singularity.dao;

import com.cqut.singularity.entity.CompetitionInformation;

public interface CompetitionInformationMapper {
    int deleteByPrimaryKey(String competitionId);

    int insert(CompetitionInformation record);

    int insertSelective(CompetitionInformation record);

    CompetitionInformation selectByPrimaryKey(String competitionId);

    int updateByPrimaryKeySelective(CompetitionInformation record);

    int updateByPrimaryKey(CompetitionInformation record);
}