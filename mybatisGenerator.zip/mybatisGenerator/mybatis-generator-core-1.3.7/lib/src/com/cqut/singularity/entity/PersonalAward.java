package com.cqut.singularity.entity;

import java.util.Date;

public class PersonalAward {
    private String awardNum;

    private String competitionId;

    private String teamLeaderNum;

    private String teamMemberNum;

    private Date publishDate;

    private String competitionWay;

    private String awardLevel;

    private String awardDescription;

    private String competitionCondition;

    public String getAwardNum() {
        return awardNum;
    }

    public void setAwardNum(String awardNum) {
        this.awardNum = awardNum == null ? null : awardNum.trim();
    }

    public String getCompetitionId() {
        return competitionId;
    }

    public void setCompetitionId(String competitionId) {
        this.competitionId = competitionId == null ? null : competitionId.trim();
    }

    public String getTeamLeaderNum() {
        return teamLeaderNum;
    }

    public void setTeamLeaderNum(String teamLeaderNum) {
        this.teamLeaderNum = teamLeaderNum == null ? null : teamLeaderNum.trim();
    }

    public String getTeamMemberNum() {
        return teamMemberNum;
    }

    public void setTeamMemberNum(String teamMemberNum) {
        this.teamMemberNum = teamMemberNum == null ? null : teamMemberNum.trim();
    }

    public Date getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }

    public String getCompetitionWay() {
        return competitionWay;
    }

    public void setCompetitionWay(String competitionWay) {
        this.competitionWay = competitionWay == null ? null : competitionWay.trim();
    }

    public String getAwardLevel() {
        return awardLevel;
    }

    public void setAwardLevel(String awardLevel) {
        this.awardLevel = awardLevel == null ? null : awardLevel.trim();
    }

    public String getAwardDescription() {
        return awardDescription;
    }

    public void setAwardDescription(String awardDescription) {
        this.awardDescription = awardDescription == null ? null : awardDescription.trim();
    }

    public String getCompetitionCondition() {
        return competitionCondition;
    }

    public void setCompetitionCondition(String competitionCondition) {
        this.competitionCondition = competitionCondition == null ? null : competitionCondition.trim();
    }
}