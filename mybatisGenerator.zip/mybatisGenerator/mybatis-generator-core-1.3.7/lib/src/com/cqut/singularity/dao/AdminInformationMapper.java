package com.cqut.singularity.dao;

import com.cqut.singularity.entity.AdminInformation;

public interface AdminInformationMapper {
    int deleteByPrimaryKey(String adminId);

    int insert(AdminInformation record);

    int insertSelective(AdminInformation record);

    AdminInformation selectByPrimaryKey(String adminId);

    int updateByPrimaryKeySelective(AdminInformation record);

    int updateByPrimaryKey(AdminInformation record);
}