package com.cqut.singularity.dao;

import com.cqut.singularity.entity.StudentInformation;

public interface StudentInformationMapper {
    int deleteByPrimaryKey(String studentId);

    int insert(StudentInformation record);

    int insertSelective(StudentInformation record);

    StudentInformation selectByPrimaryKey(String studentId);

    int updateByPrimaryKeySelective(StudentInformation record);

    int updateByPrimaryKey(StudentInformation record);
}