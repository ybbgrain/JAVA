package com.cqut.singularity.entity;

import java.util.Date;

public class CompetitionInformation {
    private String competitionId;

    private String competitionName;

    private Date competitionDate;

    private String competitionConditions;

    public String getCompetitionId() {
        return competitionId;
    }

    public void setCompetitionId(String competitionId) {
        this.competitionId = competitionId == null ? null : competitionId.trim();
    }

    public String getCompetitionName() {
        return competitionName;
    }

    public void setCompetitionName(String competitionName) {
        this.competitionName = competitionName == null ? null : competitionName.trim();
    }

    public Date getCompetitionDate() {
        return competitionDate;
    }

    public void setCompetitionDate(Date competitionDate) {
        this.competitionDate = competitionDate;
    }

    public String getCompetitionConditions() {
        return competitionConditions;
    }

    public void setCompetitionConditions(String competitionConditions) {
        this.competitionConditions = competitionConditions == null ? null : competitionConditions.trim();
    }
}