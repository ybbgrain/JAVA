package com.cqut.building.dao;

import com.cqut.building.entity.SysAcademy;

public interface SysAcademyMapper {
    int deleteByPrimaryKey(String id);

    int insert(SysAcademy record);

    int insertSelective(SysAcademy record);

    SysAcademy selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(SysAcademy record);

    int updateByPrimaryKey(SysAcademy record);
}