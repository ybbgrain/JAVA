package com.cqut.building.dao;

import com.cqut.building.entity.SysPartyMemberInformation;

public interface SysPartyMemberInformationMapper {
    int deleteByPrimaryKey(String id);

    int insert(SysPartyMemberInformation record);

    int insertSelective(SysPartyMemberInformation record);

    SysPartyMemberInformation selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(SysPartyMemberInformation record);

    int updateByPrimaryKey(SysPartyMemberInformation record);
}