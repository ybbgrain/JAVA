package com.cqut.building.dao;

import com.cqut.building.entity.SysCertificationAuditRecord;

public interface SysCertificationAuditRecordMapper {
    int deleteByPrimaryKey(String id);

    int insert(SysCertificationAuditRecord record);

    int insertSelective(SysCertificationAuditRecord record);

    SysCertificationAuditRecord selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(SysCertificationAuditRecord record);

    int updateByPrimaryKey(SysCertificationAuditRecord record);
}