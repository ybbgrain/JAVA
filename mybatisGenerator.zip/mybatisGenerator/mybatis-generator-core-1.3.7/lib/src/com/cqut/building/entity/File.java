package com.cqut.building.entity;

public class File {
    private Integer id;

    private String studentid;

    private String avatorurl;

    private String fileurl;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStudentid() {
        return studentid;
    }

    public void setStudentid(String studentid) {
        this.studentid = studentid == null ? null : studentid.trim();
    }

    public String getAvatorurl() {
        return avatorurl;
    }

    public void setAvatorurl(String avatorurl) {
        this.avatorurl = avatorurl == null ? null : avatorurl.trim();
    }

    public String getFileurl() {
        return fileurl;
    }

    public void setFileurl(String fileurl) {
        this.fileurl = fileurl == null ? null : fileurl.trim();
    }
}