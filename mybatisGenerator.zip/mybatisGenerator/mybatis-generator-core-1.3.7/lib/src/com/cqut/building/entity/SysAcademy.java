package com.cqut.building.entity;

public class SysAcademy {
    private String id;

    private String academyName;

    private String campus;

    private String schoolName;

    private Boolean isSchool;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getAcademyName() {
        return academyName;
    }

    public void setAcademyName(String academyName) {
        this.academyName = academyName == null ? null : academyName.trim();
    }

    public String getCampus() {
        return campus;
    }

    public void setCampus(String campus) {
        this.campus = campus == null ? null : campus.trim();
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName == null ? null : schoolName.trim();
    }

    public Boolean getIsSchool() {
        return isSchool;
    }

    public void setIsSchool(Boolean isSchool) {
        this.isSchool = isSchool;
    }
}